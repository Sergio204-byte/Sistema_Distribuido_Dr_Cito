module com.mycompany.interfazmedico {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires tuprolog;
    requires java.logging;
    requires jade;
    
    opens com.mycompany.interfazmedico to javafx.fxml;
    exports com.mycompany.interfazmedico;
    requires com.jfoenix;
}
