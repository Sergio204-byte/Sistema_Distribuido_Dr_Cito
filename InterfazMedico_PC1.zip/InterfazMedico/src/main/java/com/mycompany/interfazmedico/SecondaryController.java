package com.mycompany.interfazmedico;

import com.jfoenix.controls.JFXHamburger;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane; 
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import javafx.event.ActionEvent; 

public class SecondaryController implements Initializable {
    
    @FXML private VBox menuLateral;
    @FXML private JFXHamburger btnMenu;
    @FXML private Pane contentArea; // El hueco donde inyectamos las vistas
    
    private boolean menuAbierto = false;

    //Initialize Override (cONFIGURAMOS EL MENU Y EL OVERRIDE YA QUE SE IMPRIMIRA EN TODAS LAS VENTANADAS) 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Configuración inicial del menú
        menuLateral.setTranslateX(-200);
        
        loadPage("primary_1");  //Pantalla de Inicio 
    }
    
    private void loadPage(String page){
        try {
            Parent root = FXMLLoader.load(getClass().getResource(page + ".fxml"));
            
            contentArea.getChildren().clear(); 
            contentArea.getChildren().add(root); 
            
            if (menuAbierto) toggleMenu(); 
            
        } catch (IOException ex) {
            Logger.getLogger(SecondaryController.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("No se pudo cargar la vista " + page);
        }
    }
    
    //BOTONES DEL HAMBURGER MENU
    @FXML
    private void mnInicio(ActionEvent event) { 
        loadPage("primary_1");  //INICIO (INTRODUCCION Y EXPLICACION) 
    }

    @FXML
    private void mnConsulta(ActionEvent event) { 
        loadPage("secondary_3"); 
    }

    @FXML
    private void mnBusqueda(ActionEvent event) { 
        loadPage("secondary_2"); 
    }

    @FXML
    private void mnReceta(ActionEvent event) { 
        loadPage("secondary_1");
    }
    
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary"); //login
    }
    
    // --- ANIMACIÓN MENÚ ---
    @FXML
    private void toggleMenu() {
        TranslateTransition slide = new TranslateTransition();
        slide.setDuration(Duration.seconds(0.4));
        slide.setNode(menuLateral);

        if (menuAbierto) {
            slide.setToX(-200);
            menuAbierto = false;
        } else {
            slide.setToX(0);
            menuAbierto = true;
        }
        slide.play();
    }
}
