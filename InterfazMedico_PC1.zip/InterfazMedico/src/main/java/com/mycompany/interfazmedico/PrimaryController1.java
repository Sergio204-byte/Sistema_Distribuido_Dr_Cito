package com.mycompany.interfazmedico;

import java.io.IOException;
import javafx.fxml.FXML;

public class PrimaryController1 {

    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
