package com.mycompany.interfazmedico;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextArea;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class SecondaryController3 implements Initializable {

    // --- DATOS DEL PACIENTE ---
    @FXML private TextField txtNombre;
    @FXML private TextField txtEdad;
    @FXML private DatePicker dtCalendario;
    @FXML private TextField txtCurp;
    @FXML private TextField txtExpediente; // editable=false
    
    @FXML private JFXComboBox<String> cbSexo;
    @FXML private JFXComboBox<String> cbEstadoCivil;

    // --- CUADRO CLÍNICO (SÍNTOMAS) ---
    @FXML private JFXComboBox<String> cbSintomaP;   // Principal
    @FXML private JFXComboBox<String> cbSintomaSI;  // Secundario 1
    @FXML private JFXComboBox<String> cbSintomaSII; // Secundario 2
    @FXML private JFXComboBox<String> cbSintomaSIII;// Secundario 3
    @FXML private JFXComboBox<String> cbSintomaSIV; // Secundario 4
    
    @FXML private JFXTextArea txtObservaciones;

    // --- BOTONES ---
    @FXML private JFXButton btnEvaluar;
    @FXML private JFXButton btnLimpiar;

    // --- DICCIONARIO TRADUCTOR (Español -> Prolog) ---
    private Map<String, String> diccionarioSintomas = new HashMap<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarCatalogos();
        cargarDiccionarioSintomas();
    }

    private void cargarCatalogos() {
        // Llenar Sexo
        cbSexo.getItems().addAll("Masculino", "Femenino", "Otro");
        
        // Llenar Estado Civil
        cbEstadoCivil.getItems().addAll("Soltero(a)", "Casado(a)", "Divorciado(a)", "Viudo(a)");
    }

    private void cargarDiccionarioSintomas() {
        // --- AQUÍ MAPERAMOS LO QUE VE EL USUARIO VS LO QUE ENTIENDE PROLOG ---
        
        // Respiratorios
        diccionarioSintomas.put("Fiebre Moderada", "fiebre_moderada");
        diccionarioSintomas.put("Fiebre Alta", "fiebre_alta");
        diccionarioSintomas.put("Dolor Muscular", "dolor_muscular");
        diccionarioSintomas.put("Escalofríos", "escalofrios");
        diccionarioSintomas.put("Dolor de Garganta", "dolor_garganta");
        diccionarioSintomas.put("Congestión Nasal", "congestion_nasal");
        diccionarioSintomas.put("Estornudos", "estornudos");
        diccionarioSintomas.put("Tos Ligera", "tos_ligera");
        diccionarioSintomas.put("Tos Persistente", "tos_persistente");
        diccionarioSintomas.put("Ojos Llorosos", "ojos_llorosos");
        diccionarioSintomas.put("Dolor de Pecho", "dolor_pecho");
        diccionarioSintomas.put("Dificultad al Respirar", "dificultad_respirar");
        diccionarioSintomas.put("Tos con Flema", "tos_flema_color");
        diccionarioSintomas.put("Silbido al Respirar", "silbido_respiracion");
        
        // Estomacales
        diccionarioSintomas.put("Dolor Abdominal", "dolor_abdominal");
        diccionarioSintomas.put("Náuseas", "nauseas");
        diccionarioSintomas.put("Vómito", "vomito");
        diccionarioSintomas.put("Diarrea", "diarrea");
        diccionarioSintomas.put("Ardor Estomacal", "ardor_estomacal");
        
        // Cabeza y Neurológico
        diccionarioSintomas.put("Dolor de Cabeza", "dolor_cabeza");
        diccionarioSintomas.put("Mareos", "mareos");
        diccionarioSintomas.put("Visión Borrosa", "vision_borrosa");
        diccionarioSintomas.put("Fatiga", "fatiga");
        
        // Alergias / Piel
        diccionarioSintomas.put("Picazón Nasal", "picazon_nasal");
        diccionarioSintomas.put("Ojos Rojos", "ojos_rojos");
        diccionarioSintomas.put("Ronchas", "ronchas");
        diccionarioSintomas.put("Comezón", "comezon");
        
        // Oídos
        diccionarioSintomas.put("Dolor de Oído", "dolor_oido");
        diccionarioSintomas.put("Zumbidos", "zumbidos");

        // 2. Extraer las llaves (Texto en Español) y ordenarlas
        List<String> listaOrdenada = new ArrayList<>(diccionarioSintomas.keySet());
        Collections.sort(listaOrdenada);
        ObservableList<String> itemsSintomas = FXCollections.observableArrayList(listaOrdenada);

        // 3. Llenar todos los combos con la misma lista
        cbSintomaP.setItems(itemsSintomas);
        cbSintomaSI.setItems(itemsSintomas);
        cbSintomaSII.setItems(itemsSintomas);
        cbSintomaSIII.setItems(itemsSintomas);
        cbSintomaSIV.setItems(itemsSintomas);
    }

    // --- ACCIÓN: EVALUAR PACIENTE (Botón Evaluar) ---
    @FXML
    private void evaluarPaciente(ActionEvent event) {
        // 1. Recolectar síntomas seleccionados y traducirlos
        List<String> sintomasAtomos = new ArrayList<>();

        agregarSintoma(cbSintomaP, sintomasAtomos);
        agregarSintoma(cbSintomaSI, sintomasAtomos);
        agregarSintoma(cbSintomaSII, sintomasAtomos);
        agregarSintoma(cbSintomaSIII, sintomasAtomos);
        agregarSintoma(cbSintomaSIV, sintomasAtomos);

        // 2. Validaciones básicas
        if (sintomasAtomos.isEmpty()) {
            mostrarAlerta("Datos Incompletos", "Por favor seleccione al menos el Síntoma Principal.");
            return;
        }

        if (txtNombre.getText().trim().isEmpty()) {
             mostrarAlerta("Datos Incompletos", "Falta el nombre del paciente.");
             return;
        }

        // 3. PREPARAR DATOS (Sincronización con PC 2)
        
        // A) Nombre (Limpiamos ; para evitar errores de formato)
        String nombre = txtNombre.getText().replace(";", ""); 
        
        // B) Alergia
        // SI TIENES UN CAMPO EN LA INTERFAZ, ÚSALO ASÍ:
        // String alergia = txtAlergias.getText().isEmpty() ? "ninguna" : txtAlergias.getText();
        String alergia = "ninguna"; // Valor por defecto si no hay campo en la GUI

        // C) Síntomas (Unidos por comas)
        String sintomas = String.join(",", sintomasAtomos);

        // 4. ARMAR EL PAQUETE COMPLETO
        // Formato esperado por Enfermera: NOMBRE ; ALERGIA ; SINTOMAS
        String mensajeCompleto = nombre + ";" + alergia + ";" + sintomas;

        // 5. Imprimir en consola para depuración
        System.out.println("========================================");
        System.out.println("🚀 ENVIANDO AL SISTEMA EXPERTO...");
        System.out.println("📦 Paquete: " + mensajeCompleto);
        System.out.println("========================================");
        
        // 6. ENVIAR A TRAVÉS DEL PUENTE
        PuenteAgentes.getInstancia().pedirDiagnostico(mensajeCompleto);

        mostrarAlerta("Consulta Enviada", "La Enfermera Virtual está procesando el diagnóstico...");
    }

    // --- ACCIÓN: LIMPIAR (Botón Limpiar) ---
    @FXML
    private void limpiarFormulario(ActionEvent event) {
        txtNombre.clear();
        txtEdad.clear();
        txtCurp.clear();
        txtExpediente.clear();
        dtCalendario.setValue(null);
        txtObservaciones.clear();
        
        cbSexo.getSelectionModel().clearSelection();
        cbEstadoCivil.getSelectionModel().clearSelection();
        
        cbSintomaP.getSelectionModel().clearSelection();
        cbSintomaSI.getSelectionModel().clearSelection();
        cbSintomaSII.getSelectionModel().clearSelection();
        cbSintomaSIII.getSelectionModel().clearSelection();
        cbSintomaSIV.getSelectionModel().clearSelection();
        
        System.out.println("Formulario limpiado.");
    }

    // --- MÉTODOS AUXILIARES ---
    
    private void agregarSintoma(JFXComboBox<String> combo, List<String> lista) {
        String seleccion = combo.getValue();
        // Si hay algo seleccionado y existe en el diccionario
        if (seleccion != null && !seleccion.isEmpty() && diccionarioSintomas.containsKey(seleccion)) {
            lista.add(diccionarioSintomas.get(seleccion)); // Agrega el valor Prolog (ej: fiebre_alta)
        }
    }

    private void mostrarAlerta(String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}