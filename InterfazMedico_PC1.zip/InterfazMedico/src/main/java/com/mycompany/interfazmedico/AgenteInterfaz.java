package com.mycompany.interfazmedico;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class AgenteInterfaz extends Agent {

    private PuenteAgentes puente;

    @Override
    protected void setup() {
        // Obtenemos referencia al puente para poder avisarle a la GUI
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            puente = (PuenteAgentes) args[0];
            puente.setAgente(this);
        }

        // Comportamiento para escuchar respuestas
        addBehaviour(new CyclicBehaviour() {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    // Le avisamos al puente que llegó correo del Servidor
                    puente.recibirRespuesta(msg.getContent(), "RESPUESTA");
                } else {
                    block();
                }
            }
        });
    }

    public void enviarMensaje(String destinatario, String contenido, String protocolo) {
        ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
        // El destinatario es "Enfermera" (el nombre local en el contenedor principal)
        msg.addReceiver(new AID(destinatario, AID.ISLOCALNAME));
        msg.setLanguage("Español");
        msg.setOntology("Medico");
        msg.setContent(contenido);
        msg.setConversationId(protocolo); 
        send(msg);
    }
}