package com.mycompany.interfazmedico;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import javafx.application.Platform;
import javafx.scene.control.Alert;

public class PuenteAgentes {
    
    //private SecondaryController1 controladorRecetas;

    // 👇 --- AGREGA ESTO (VARIABLE NUEVA) --- 👇

    private static PuenteAgentes instancia;
    private AgenteInterfaz miAgente;
    private ContainerController container;
    private SecondaryController1 controladorRecetas;
    private SecondaryController2 controladorBusqueda;

    // Aquí pon la IP que te dio el ipconfig en PC 2 (ZeroTier)
    private static final String IP_SERVIDOR = "10.29.175.178"; 
    private static final String PUERTO = "1234"; 

    public void setControladorRecetas(SecondaryController1 controller) {
        this.controladorRecetas = controller;
    }

    private PuenteAgentes() {
        iniciarContenedor();
    }

    public static PuenteAgentes getInstancia() {
        if (instancia == null) {
            instancia = new PuenteAgentes();
        }
        return instancia;
    }

    private void iniciarContenedor() {
        try {
            System.out.println("Iniciando Contenedor Cliente JADE...");
            Runtime rt = Runtime.instance();
            Profile p = new ProfileImpl();
            
            // 1. Configuración para NO mostrar otra ventana de JADE aquí
            p.setParameter(Profile.GUI, "false");
            
            // 2. Conexión al Jefe (PC 2)
            p.setParameter(Profile.MAIN_HOST, IP_SERVIDOR);
            p.setParameter(Profile.MAIN_PORT, PUERTO);
            
            // 3. Nombre de este contenedor (PC 1)
            p.setParameter(Profile.LOCAL_HOST, "10.29.175.133");

            container = rt.createAgentContainer(p);
            
            System.out.println(" Conectado al Main Container en: " + IP_SERVIDOR);
            
            // 4. Crear nuestro agente mensajero
            // Pasamos 'this' (el puente) como argumento para que el agente nos pueda hablar
            AgentController ac = container.createNewAgent("AgenteInterfaz", 
                                 "com.mycompany.interfazmedico.AgenteInterfaz", 
                                 new Object[]{this});
            ac.start();

        } catch (Exception e) {
            System.err.println(" Error crítico iniciando JADE en Cliente:");
            e.printStackTrace();
            mostrarAlertaError("Error de Conexión", "No se pudo conectar con el Servidor Médico.\nVerifique que PC 2 esté encendida y la IP sea correcta.");
        }
    }

    // Este método lo llama el AgenteInterfaz cuando nace
    public void setAgente(AgenteInterfaz agente) {
        this.miAgente = agente;
        System.out.println("🔗 Agente Interfaz vinculado correctamente.");
    }

    public void setControladorBusqueda(SecondaryController2 controller) {
        this.controladorBusqueda = controller;
        System.out.println("🔗 Controlador de Búsqueda vinculado.");
    }
    // --- MÉTODOS DE ENVÍO (De GUI -> JADE) ---
    
    public void pedirDiagnostico(String sintomas) {
        if (miAgente != null) {
            
            String destinatario = "Enfermera"; // Por defecto (Diagnóstico)
            
            // 🧠 CEREBRO DE ENRUTAMIENTO
            if (sintomas.startsWith("BUSCAR:")) {
                destinatario = "GestorBD"; // ¡Cambio de vía hacia el Archivista!
            }
            
            System.out.println("Puente enviando a [" + destinatario + "]: " + sintomas);
            
            // Usamos la variable 'destinatario' en lugar de "Enfermera" fijo
            miAgente.enviarMensaje(destinatario, sintomas, "SOLICITUD");
            
        } else {
            System.err.println("El Agente Interfaz no está listo todavía.");
            mostrarAlertaError("Error", "Agente no conectado.");
        }
    }

    // --- MÉTODOS DE RECEPCIÓN (De JADE -> GUI) ---
    
public void recibirRespuesta(String contenido, String tipo) {
        System.out.println("🔔 GUI RECIBIÓ: " + contenido);

        javafx.application.Platform.runLater(() -> {
            try {
                // CASO 1: ES UNA RECETA (Viene de Enfermera con ; y NO es un historial)
                // Agregamos !contenido.startsWith("FECHA") para evitar confusiones con reportes de BD
                if (contenido.contains(";") && !contenido.startsWith("FECHA")) {
                    
                    String[] partes = contenido.split(";");
                    
                    if (partes.length >= 3) {
                        
                        // 1. MOSTRAR ALERTA DE "ÉXITO"
                        Alert exito = new Alert(Alert.AlertType.INFORMATION);
                        exito.setTitle("Análisis Completado");
                        exito.setHeaderText("El Sistema Experto ha finalizado el diagnóstico.");
                        exito.setContentText("Se han generado las recetas y costos correspondientes.\nPresione Aceptar para ver los detalles.");
                        exito.showAndWait(); 

                        // 2. CARGAR VISTA DE RECETAS
                        javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("secondary_1.fxml"));
                        javafx.scene.Parent root = loader.load();

                        // 3. PASAR DATOS AL CONTROLADOR DE RECETAS
                        SecondaryController1 controller = loader.getController();
                        controller.recibirDatosDelSistema(partes[0], partes[1], partes[2]);

                        // 4. CAMBIAR DE PANTALLA AUTOMÁTICAMENTE
                        javafx.stage.Window window = javafx.stage.Window.getWindows().stream().filter(javafx.stage.Window::isShowing).findFirst().orElse(null);
                        if (window instanceof javafx.stage.Stage) {
                            ((javafx.stage.Stage) window).setScene(new javafx.scene.Scene(root));
                            // Centrar pantalla si es necesario
                            ((javafx.stage.Stage) window).centerOnScreen();
                        }
                    } 
                } 
                
                // CASO 2: ES UN HISTORIAL (Viene de BD)
                else if (contenido.contains("----------------") || contenido.startsWith("No se encontró")) {
                    
                    // CORRECCIÓN AQUÍ: Usamos la variable 'controladorBusqueda', NO la clase
                    if (controladorBusqueda != null) {
                        controladorBusqueda.mostrarResultados(contenido);
                    } else {
                        // Si el usuario no está en la pantalla de búsqueda, mostramos alerta
                        mostrarAlertaInfo("Historial Médico", contenido);
                    }
                }
                
                // CASO 3: MENSAJE GENÉRICO O ERROR
                else {
                    mostrarAlertaInfo("Sistema", contenido);
                }
                
            } catch (Exception e) {
                e.printStackTrace();
                System.err.println("Error procesando respuesta: " + e.getMessage());
            }
        });
    }
    
    
    
    
    
    // --- Utilidades ---
    
    private void mostrarAlertaInfo(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.show();
    }
    
    private void mostrarAlertaError(String titulo, String mensaje) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(titulo);
            alert.setHeaderText(null);
            alert.setContentText(mensaje);
            alert.show();
        });
    }
}