package com.mycompany.interfazmedico;

import com.jfoenix.controls.JFXTextArea; // O javafx.scene.control.TextArea
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import java.net.URL;
import java.util.ResourceBundle;

public class SecondaryController2 implements Initializable {

    // --- ELEMENTOS DE LA INTERFAZ ---
    @FXML private TextField txtInputBusqueda; // Donde escribes la CURP/Nombre
    
    // Estos son los cuadros grises grandes de la derecha
    @FXML private JFXTextArea txtSintomasArea; 
    @FXML private JFXTextArea txtObservacionesArea; 

    // Referencia estática para que el Puente nos encuentre
    private static SecondaryController2 instancia;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        instancia = this; // Nos registramos para recibir mensajes
        // Vincular con el Puente
        PuenteAgentes.getInstancia().setControladorBusqueda(this);
    }
    
    // --- ACCIÓN DEL BOTÓN BUSCAR ---
    @FXML
    private void buscarHistorial(ActionEvent event) {
        String termino = txtInputBusqueda.getText().trim();
        if (termino.isEmpty()) {
            mostrarAlerta("Error", "Ingrese un nombre o CURP.");
            return;
        }
        
        // Limpiamos las áreas antes de buscar
        txtSintomasArea.clear();
        txtObservacionesArea.clear();
        
        // Pedimos al Agente BD
        PuenteAgentes.getInstancia().pedirDiagnostico("BUSCAR:" + termino);
    }

    // --- MÉTODO MAGICO: RECIBE Y PINTA LOS DATOS ---
    public void mostrarResultados(String reporteBD) {
        
        if (reporteBD.startsWith("No se encontró")) {
            mostrarAlerta("Sin Resultados", reporteBD);
            return;
        }

        // EL PARSEO (Despedazar el texto)
        try {
            // 1. Separamos por las líneas divisorias "----------------"
            // El primer elemento [0] será la consulta MÁS RECIENTE porque la BD ordena DESC
            String[] consultas = reporteBD.split("-----------------------------------");
            
            if (consultas.length > 0) {
                String ultimaConsulta = consultas[0].trim();
                
                // 2. Separamos por líneas (Enter)
                String[] lineas = ultimaConsulta.split("\n");
                
                // Estructura esperada de ConexionBD:
                // Linea 0: Fecha
                // Linea 1: Sintomas
                // Linea 2: Diagnostico
                
                if (lineas.length >= 3) {
                    String fecha = lineas[0].trim();
                    String sintomas = lineas[1].trim();
                    String diagnostico = lineas[2].trim();
                    
                    // 3. PINTAMOS EN LA GUI
                    txtSintomasArea.setText("FECHA: " + fecha + "\n\n" + sintomas);
                    txtObservacionesArea.setText(diagnostico.toUpperCase());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            txtObservacionesArea.setText("Error al leer el historial.");
        }
    }
    
    
    
    private void mostrarAlerta(String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(contenido);
        alert.show();
    }
    
    @FXML
    private void limpiarBusqueda(ActionEvent event) {
        // 1. Limpiar campo de entrada
        txtInputBusqueda.clear();
        
        // 2. Limpiar áreas grandes de resultados
        if(txtSintomasArea != null) txtSintomasArea.clear();
        if(txtObservacionesArea != null) txtObservacionesArea.clear();
    }
}