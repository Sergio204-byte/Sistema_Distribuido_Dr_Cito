package com.mycompany.interfazmedico;

import com.jfoenix.controls.JFXTextArea;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import java.util.Optional;
import java.util.Arrays;

public class SecondaryController1 {

    // --- LADO IZQUIERDO (Se llena al entrar) ---
    @FXML private TextArea txtDiagnostico;
    @FXML private TextArea txtTratamiento; // O JFXTextArea
    @FXML private TextArea txtAlerta;      // O Label/TextField

    // --- LADO DERECHO (Ticket) ---
    @FXML private TextArea arPRODUCTOS; 
    @FXML private TextArea arPRECIO; 
    
    @FXML private Label lblCajero;

    // --- VARIABLES OCULTAS (Para guardar el precio hasta dar clic en Generar) ---
    private String costoRecibido = "0";
    private String diagnosticoRecibido = "";

    // --- MÉTODO 1: RECIBIR DATOS (Lo llama el Puente al cambiar de ventana) ---
    public void recibirDatosDelSistema(String diagnostico, String tratamiento, String infoCosto) {
        this.diagnosticoRecibido = diagnostico;
        
        // 1. Limpiamos el costo para tener solo el número
        try {
            if(infoCosto.contains("$")) {
                this.costoRecibido = infoCosto.split("\\$")[1].trim(); 
            } else {
                this.costoRecibido = infoCosto.replace("Costo estimado:", "").trim();
            }
        } catch (Exception e) { this.costoRecibido = "0.00"; }

        // 2. LLENAR EL LADO IZQUIERDO DE INMEDIATO
        txtDiagnostico.setText(diagnostico.toUpperCase());
        txtTratamiento.setText(tratamiento);
        
        // Lógica simple para la alerta (puedes mejorarla si el backend manda alerta específica)
        if (tratamiento.toLowerCase().contains("sustitucion")) {
            txtAlerta.setText("⚠️ ALERTA: Medicamento sustituido por alergia detectada.");
        } else {
            txtAlerta.setText("✅ Tratamiento seguro. Sin contraindicaciones.");
        }
    }

    // --- MÉTODO 2: BOTÓN GENERAR (Pinta el Ticket) ---
    @FXML
    private void generarTicket(ActionEvent event) {
        double precio = Double.parseDouble(costoRecibido);
        double iva = precio * 0.16;
        double total = precio + iva;
        
        lblCajero.setText("AGENTE IA");
        //arPRECIO.setText(String.format("$ %.2f", total));
        
        StringBuilder ticket = new StringBuilder();
        ticket.append("CANT.   DESCRIPCION             IMPORTE\n");
        ticket.append("---------------------------------------\n");
        ticket.append("1       CONSULTA MEDICA         $ 0.00\n");
        ticket.append("1       TRATAMIENTO             $ " + costoRecibido + "\n");
        ticket.append("        (" + diagnosticoRecibido + ")\n");
        ticket.append("\n");
        ticket.append("SUBTOTAL:                       $ " + String.format("%.2f", precio) + "\n");
        ticket.append("IVA (16%):                      $ " + String.format("%.2f", iva) + "\n");
        ticket.append("---------------------------------------\n");
        ticket.append("TOTAL:                          $ " + String.format("%.2f", total) + "\n");
        
        arPRODUCTOS.setText(ticket.toString());
    }

    // --- MÉTODO 3: BOTÓN ENVIAR (Flujo de Pago) ---
    @FXML
    private void procesarPago(ActionEvent event) {
        // 1. Preguntar Forma de Pago
        ChoiceDialog<String> dialog = new ChoiceDialog<>("Efectivo", Arrays.asList("Efectivo", "Tarjeta de Crédito/Débito"));
        dialog.setTitle("Procesar Pago");
        dialog.setHeaderText("Seleccione el método de pago");
        dialog.setContentText("Método:");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()){
            
            // 2. Mensaje de Agradecimiento
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Pago Exitoso");
            alert.setHeaderText("¡Gracias por su compra!");
            alert.setContentText("El comprobante se ha enviado al sistema.\nPresione Aceptar para finalizar.");
            alert.showAndWait();

            // 3. RETORNAR AL INICIO (Menú Principal)
            regresarAlMenu();
        }
    }

    private void regresarAlMenu() {
        try {
            // Cargar tu vista principal (Asegúrate que el nombre sea correcto, ej: "secondary.fxml" o el dashboard)
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("secondary.fxml")); 
            javafx.scene.Parent root = loader.load();
            
            // Obtener escenario actual y cambiar escena
            javafx.stage.Stage stage = (javafx.stage.Stage) txtDiagnostico.getScene().getWindow();
            stage.setScene(new javafx.scene.Scene(root));
            stage.show();
            System.out.println(" Sistema reiniciado correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}