package com.mycompany.interfazmedico;

import java.io.IOException;
import javafx.fxml.FXML;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class PrimaryController {
    
    @FXML 
    private TextField txtUsuario;
    
    @FXML
    private PasswordField txtContrasena;
    
    
    @FXML
    private void btnIngresar () throws IOException {
        String user = txtUsuario.getText();
        String pass = txtContrasena.getText();
        
        if (user.equals("admin") && pass.equals("1234")){
            
            // --- CAMBIO AQUÍ ---
            // Cargamos el MARCO (que contiene el menú)
            App.setRoot("secondary"); 
            
        } else {
            mostrarAlerta("Acceso Denegado", "Usuario o contraseña incorrectos");
        }
        

    }
    
    private void mostrarAlerta(String titulo, String mensaje){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
